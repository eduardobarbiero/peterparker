import java.sql.Date;
import java.util.Set;

import javax.xml.crypto.Data;


public class TicketDispositivos {
	
	private Long id;
	
	private Long ticketId;
	
	private Long dipositivoId;
	
	private Date data;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getTicketId() {
		return ticketId;
	}

	public void setTicketId(Long ticketId) {
		this.ticketId = ticketId;
	}

	public Long getDipositivoId() {
		return dipositivoId;
	}

	public void setDipositivoId(Long dipositivoId) {
		this.dipositivoId = dipositivoId;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	
	
	
	
	
	
	
	
	
	
	
	

}
